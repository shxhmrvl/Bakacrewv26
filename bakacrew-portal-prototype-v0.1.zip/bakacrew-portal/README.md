# BakaCrew Portal — Prototype v0.1

A responsive bilingual (English / Bahasa Melayu) static prototype for the BakaCrew gaming + weeb + otaku community.

## Included
- Community overview homepage
- Functional single-page navigation
- BM / EN language toggle
- Dark / light theme toggle
- Minecraft SMP page with copy IP/port controls
- Anime & manga sample catalog with search and category filters
- News and demo member directory with search
- Sample events with demo-only RSVP interaction
- Admin dashboard preview with demo-only add/edit actions
- Sign-in modal clearly marked non-functional
- Responsive layout for desktop and mobile

## Prototype limitations
This is frontend-only. No authentication, database, admin authorization, actual RSVP submissions, persistent content management, or live Minecraft status API is connected. Statistics, members, catalog entries and most events are demo data. Do not enter real passwords or sensitive information.

The IP and port below were supplied in the project conversation. The server status has deliberately not been verified:
- IP: `play.bakacrew.xyz`
- Port: `30693`

## Test locally
Open `index.html` in a modern browser. To run a local web server (optional), use:
```bash
python -m http.server 8000
```
Then open `http://localhost:8000`.

## Publish using GitHub Pages
1. Create a new GitHub repository named `bakacrew-portal` (public is simplest for a public portal).
2. Upload all project files including the `.github/workflows/pages.yml` workflow.
3. In **Settings → Pages**, set the source/build configuration to GitHub Actions if prompted.
4. Push/commit to the `main` branch. The included workflow deploys the static files.
5. Check the **Actions** tab for the deployment run. The Pages URL is shown in the workflow deployment/environment and Settings → Pages.

If you prefer, GitHub Pages can also publish the root folder using “Deploy from a branch”; the included workflow is intended for the GitHub Actions route.

## Project structure
- `index.html` — semantic page structure and content
- `styles.css` — visual system, components, responsive breakpoints and themes
- `app.js` — navigation, translations, demo data, filtering and UI actions
- `.github/workflows/pages.yml` — GitHub Pages deployment workflow

## Suggested milestones
1. Review UI and replace sample posts/events/members with approved content.
2. Add official BakaCrew logo, rules and correct social/Discord links.
3. Choose and implement a backend and authentication solution.
4. Implement role-based authorization on the server before enabling admin tools.
5. Integrate a reliable Minecraft status provider/API with timestamps and error handling.
6. Add database-backed content management for news, events and profiles.
